import { useState, useRef, useEffect, createContext, useContext } from "react";

// ─── html2canvas loader ───────────────────────────────────────────────────────
function useH2C() {
  const [ok, setOk] = useState(!!window.html2canvas);
  useEffect(() => {
    if (window.html2canvas) { setOk(true); return; }
    const s = document.createElement("script");
    s.src = "https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js";
    s.onload = () => setOk(true);
    document.head.appendChild(s);
  }, []);
  return ok;
}

// ─── Selar PRO payment ────────────────────────────────────────────────────────
const SELAR_LINK = "https://selar.com/75211y6891";

function useSelarPay() {
  const { unlock } = usePro();
  const pay = (onOpened) => {
    window.open(SELAR_LINK, "_blank");
    onOpened && onOpened();
  };
  return { pay };
}

// ─── PRO Context ──────────────────────────────────────────────────────────────
// Persisted in localStorage so PRO survives page refresh
const ProCtx = createContext(null);
function ProProvider({ children }) {
  const [isPro, setIsPro] = useState(() => {
    try { return localStorage.getItem("prankforge_pro") === "true"; } catch { return false; }
  });
  const unlock = () => {
    setIsPro(true);
    try { localStorage.setItem("prankforge_pro", "true"); } catch {}
  };
  return <ProCtx.Provider value={{ isPro, unlock }}>{children}</ProCtx.Provider>;
}
const usePro = () => useContext(ProCtx);

// ─── Paystack pay hook removed — using Selar ─────────────────────────────────

// ─── Theme ───────────────────────────────────────────────────────────────────
const T = {
  bg:"#0f0f13", surface:"#1a1a24", border:"#2e2e42",
  accent:"#7c3aed", accentLight:"#a855f7", accentGlow:"rgba(124,58,237,0.18)",
  danger:"#ef4444", success:"#22c55e", text:"#f1f0ff", muted:"#8b8ba7",
  waGreen:"#25d366", fb:"#1877f2",
};
const lbl = { display:"block", color:T.muted, fontSize:"11px", fontWeight:600, textTransform:"uppercase", letterSpacing:"0.06em", marginBottom:"5px" };
const inp = { width:"100%", padding:"9px 12px", background:T.bg, border:`1px solid ${T.border}`, borderRadius:"8px", color:T.text, fontSize:"14px", outline:"none", boxSizing:"border-box" };

// ─── Avatar (outside preview — click handler safe for html2canvas) ────────────
function Avatar({ image, size=42, initials="?", bgColor="#555" }) {
  return (
    <div style={{ width:size, height:size, borderRadius:"50%", background:bgColor,
      display:"flex", alignItems:"center", justifyContent:"center",
      overflow:"hidden", flexShrink:0 }}>
      {image
        ? <img src={image} style={{ width:"100%", height:"100%", objectFit:"cover" }} alt="av" />
        : <span style={{ color:"#fff", fontWeight:700, fontSize:size*0.38 }}>{initials}</span>}
    </div>
  );
}
// Upload trigger lives OUTSIDE preview
function AvatarPicker({ label, image, onImage, size=48, initials="?", bgColor="#555" }) {
  const ref = useRef();
  const handleFile = e => {
    const f = e.target.files[0]; if (!f) return;
    const r = new FileReader(); r.onload = ev => onImage(ev.target.result); r.readAsDataURL(f);
  };
  return (
    <div style={{ display:"flex", alignItems:"center", gap:"12px",
      background:T.bg, border:`1px solid ${T.border}`, borderRadius:"10px", padding:"12px", marginBottom:"14px" }}>
      <div onClick={()=>ref.current.click()} style={{ cursor:"pointer", position:"relative" }}>
        <Avatar image={image} size={size} initials={initials} bgColor={bgColor} />
        <div style={{ position:"absolute", bottom:0, right:0, width:18, height:18, borderRadius:"50%",
          background:T.accent, display:"flex", alignItems:"center", justifyContent:"center",
          border:"2px solid #0f0f13", fontSize:"9px" }}>📷</div>
        <input ref={ref} type="file" accept="image/*" onChange={handleFile} style={{ display:"none" }} />
      </div>
      <div>
        <div style={{ color:T.text, fontWeight:600, fontSize:"14px" }}>{label}</div>
        <div style={{ color:T.muted, fontSize:"12px" }}>{image ? "✅ Photo set — tap to change" : "Tap to upload photo"}</div>
      </div>
    </div>
  );
}

// ─── PRO / Ad context (global for this session) ──────────────────────────────
// In production this would be persisted via AsyncStorage / backend
let _wmRemoved = false;
let _setWmRemovedGlobal = null;

// ─── Remove Watermark Modal ───────────────────────────────────────────────────
function RemoveWMModal({ onClose, onRemoved }) {
  const [watching, setWatching]   = useState(false);
  const [adDone, setAdDone]       = useState(false);
  const [selarOpened, setSelarOpened] = useState(false);
  const [activating, setActivating]   = useState(false);
  const [badCode, setBadCode]         = useState(false);
  const { isPro, unlock }         = usePro();
  const { pay }                   = useSelarPay();

  useEffect(() => { if (isPro) { onRemoved(); onClose(); } }, []);

  const watchAd = () => {
    setWatching(true);
    setTimeout(() => { setAdDone(true); setWatching(false); }, 5000);
  };

  const openSelar = () => {
    pay();
    setSelarOpened(true);
  };

  const activatePro = () => {
    // In production you'd verify a Selar order ID via webhook
    // For now trust user — they paid on Selar, we unlock
    setActivating(true);
    setTimeout(() => {
      unlock();
      onRemoved();
      onClose();
      setActivating(false);
    }, 1000);
  };

  return (
    <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.88)", zIndex:2000,
      display:"flex", alignItems:"center", justifyContent:"center", padding:"20px" }}>
      <div style={{ background:T.surface, border:`1px solid ${T.border}`, borderRadius:"20px",
        padding:"28px", maxWidth:"340px", width:"100%", textAlign:"center" }}>

        {/* ── AD WATCHED STATE ── */}
        {adDone ? (
          <>
            <div style={{ fontSize:"48px", marginBottom:"10px" }}>🎉</div>
            <div style={{ color:T.success, fontWeight:800, fontSize:"18px", marginBottom:"8px" }}>Ad Watched!</div>
            <div style={{ color:T.muted, fontSize:"13px", marginBottom:"22px" }}>
              Watermark removed for this save only 😄
            </div>
            <button onClick={()=>{ onRemoved(); onClose(); }} style={{
              width:"100%", padding:"14px", background:T.success,
              color:"#fff", border:"none", borderRadius:"12px",
              fontWeight:700, fontSize:"15px", cursor:"pointer",
            }}>✅ Done — Watermark Removed!</button>
          </>

        /* ── SELAR OPENED — waiting for activation ── */
        ) : selarOpened ? (
          <>
            <div style={{ fontSize:"40px", marginBottom:"10px" }}>⏳</div>
            <div style={{ color:T.text, fontWeight:800, fontSize:"17px", marginBottom:"8px" }}>
              Complete Payment on Selar
            </div>
            <div style={{ color:T.muted, fontSize:"13px", marginBottom:"6px", lineHeight:1.6 }}>
              Selar opened in a new tab. Pay ₦1,000 there, then come back and tap the button below.
            </div>
            <div style={{ background:"rgba(245,158,11,0.1)", border:"1px solid rgba(245,158,11,0.3)",
              borderRadius:"10px", padding:"10px", marginBottom:"20px" }}>
              <div style={{ color:"#f59e0b", fontSize:"12px" }}>
                📧 Check your email after payment — Selar sends a receipt. Come back here after paying.
              </div>
            </div>
            <button onClick={activatePro} disabled={activating} style={{
              width:"100%", padding:"14px", marginBottom:"10px",
              background:`linear-gradient(135deg,${T.accent},#4f46e5)`,
              color:"#fff", border:"none", borderRadius:"12px",
              fontWeight:700, fontSize:"15px", cursor:activating?"wait":"pointer",
              display:"flex", alignItems:"center", justifyContent:"center", gap:"8px",
            }}>
              {activating ? <><AdSpinner/>Activating…</> : <>⭐ I've Paid — Activate PRO</>}
            </button>
            <button onClick={openSelar} style={{ background:"none", border:"none",
              color:T.muted, fontSize:"13px", cursor:"pointer" }}>
              Reopen payment page
            </button>
          </>

        /* ── DEFAULT STATE ── */
        ) : (
          <>
            <div style={{ fontSize:"36px", marginBottom:"10px" }}>🚫💧</div>
            <div style={{ color:T.text, fontWeight:800, fontSize:"18px", marginBottom:"8px" }}>Remove Watermark</div>
            <div style={{ color:T.muted, fontSize:"13px", marginBottom:"22px", lineHeight:1.6 }}>
              Choose how to remove the watermark
            </div>

            {/* Watch ad */}
            <button onClick={watchAd} disabled={watching} style={{
              width:"100%", padding:"14px", marginBottom:"12px",
              background:watching?"#333":`linear-gradient(135deg,#f59e0b,#d97706)`,
              color:"#fff", border:"none", borderRadius:"12px",
              fontWeight:700, fontSize:"15px", cursor:watching?"wait":"pointer",
              display:"flex", alignItems:"center", justifyContent:"center", gap:"8px",
            }}>
              {watching ? <><AdSpinner/> Watching… (5s)</> : <>📺 Watch Ad — Free (this save only)</>}
            </button>

            <div style={{ color:T.muted, fontSize:"12px", marginBottom:"12px" }}>— or —</div>

            {/* Selar PRO */}
            <button onClick={openSelar} style={{
              width:"100%", padding:"14px", marginBottom:"18px",
              background:`linear-gradient(135deg,${T.accent},#4f46e5)`,
              color:"#fff", border:"none", borderRadius:"12px",
              fontWeight:700, fontSize:"15px", cursor:"pointer",
            }}>⭐ Go PRO — ₦1,000 Forever</button>

            <div style={{ color:T.muted, fontSize:"11px", marginBottom:"16px" }}>
              🔒 Secured by Selar · Cards, Bank Transfer, USSD
            </div>

            <button onClick={onClose} style={{ background:"none", border:"none",
              color:T.muted, fontSize:"13px", cursor:"pointer" }}>Cancel</button>
          </>
        )}
      </div>
    </div>
  );
}

function AdSpinner() {
  return <span style={{ width:"14px", height:"14px", border:"2px solid rgba(255,255,255,0.3)",
    borderTop:"2px solid #fff", borderRadius:"50%", display:"inline-block",
    animation:"spin 0.7s linear infinite" }}/>;
}

// ─── Watermark ────────────────────────────────────────────────────────────────
function WM({ removed = false, onRemoveClick }) {
  if (removed) return null;
  return (
    <div style={{ position:"absolute", inset:0, zIndex:99,
      display:"flex", alignItems:"flex-end", justifyContent:"flex-end", padding:"6px" }}>
      <div style={{ display:"flex", alignItems:"center", gap:"0",
        background:"rgba(0,0,0,0.45)", borderRadius:"6px", overflow:"hidden" }}>
        <span style={{ color:"rgba(255,255,255,0.7)", fontSize:"8px", fontWeight:700,
          letterSpacing:"0.06em", padding:"3px 7px", fontFamily:"monospace",
          textTransform:"uppercase" }}>PrankForge</span>
        {/* Red × tap target — lives OUTSIDE preview capture area */}
        <button onClick={onRemoveClick} style={{
          background:"rgba(239,68,68,0.85)", border:"none", color:"#fff",
          fontSize:"11px", fontWeight:900, padding:"3px 7px",
          cursor:"pointer", lineHeight:1, display:"flex", alignItems:"center",
        }}>×</button>
      </div>
    </div>
  );
}

// ─── Status bar ───────────────────────────────────────────────────────────────
function StatusBar({ time="6:22", dark=false }) {
  const c = dark ? "#fff" : "#000";
  return (
    <div style={{ background: dark?"#000":"#fff", padding:"5px 14px 3px",
      display:"flex", justifyContent:"space-between", alignItems:"center" }}>
      <span style={{ color:c, fontSize:"12px", fontWeight:700 }}>{time}</span>
      <div style={{ display:"flex", alignItems:"center", gap:"4px" }}>
        <span style={{ color:c, fontSize:"10px" }}>LTE</span>
        <span style={{ color:c, fontSize:"11px" }}>📶</span>
        <span style={{ color:c, fontSize:"11px" }}>🔋98%</span>
      </div>
    </div>
  );
}

// ─── Save bar ─────────────────────────────────────────────────────────────────
function SaveBar({ previewRef, filename, wmRemoved, onWmRemoved, onOpenModal }) {
  const [saving, setSaving] = useState(false);
  const [saved, setSaved]   = useState(false);
  // modal is now lifted to parent
  const ready = useH2C();

  const capture = async () => window.html2canvas(previewRef.current, {
    useCORS:true, scale:2, backgroundColor:null, logging:false,
  });

  const doSave = async () => {
    if (!ready||!previewRef.current) return;
    setSaving(true);
    try {
      const c = await capture();
      const a = document.createElement("a");
      a.download=`${filename}-prankforge.png`; a.href=c.toDataURL("image/png"); a.click();
      setSaved(true); setTimeout(()=>setSaved(false),3000);
    } catch(e){ alert("Save failed, try again"); }
    setSaving(false);
  };

  const doShare = async () => {
    if (!ready||!previewRef.current) return;
    setSaving(true);
    try {
      const c = await capture();
      c.toBlob(async blob => {
        const file = new File([blob],`${filename}-prankforge.png`,{type:"image/png"});
        if (navigator.share && navigator.canShare({files:[file]}))
          await navigator.share({files:[file],title:"PrankForge 😂",text:"Check this out 👀"});
        else {
          const a=document.createElement("a");
          a.download=`${filename}-prankforge.png`; a.href=c.toDataURL("image/png"); a.click();
        }
        setSaving(false);
      });
    } catch(e){ setSaving(false); }
  };

  return (
    <>
      {/* Watermark status hint */}
      {!wmRemoved && (
        <div onClick={onOpenModal} style={{
          marginTop:"12px", display:"flex", alignItems:"center", gap:"8px",
          background:"rgba(239,68,68,0.08)", border:"1px solid rgba(239,68,68,0.2)",
          borderRadius:"10px", padding:"9px 14px", cursor:"pointer",
        }}>
          <span style={{ fontSize:"14px" }}>🚫</span>
          <span style={{ color:"#f87171", fontSize:"13px", flex:1 }}>
            Watermark is on — tap to remove it free
          </span>
          <span style={{ color:"#f87171", fontSize:"18px" }}>›</span>
        </div>
      )}
      {wmRemoved && (
        <div style={{
          marginTop:"12px", display:"flex", alignItems:"center", gap:"8px",
          background:"rgba(34,197,94,0.08)", border:"1px solid rgba(34,197,94,0.2)",
          borderRadius:"10px", padding:"9px 14px",
        }}>
          <span style={{ fontSize:"14px" }}>✅</span>
          <span style={{ color:T.success, fontSize:"13px" }}>Watermark removed for this save!</span>
        </div>
      )}

      <div style={{ display:"flex", gap:"10px", marginTop:"10px" }}>
        <button onClick={doSave} disabled={saving||!ready} style={{
          flex:1, padding:"13px", border:"none", borderRadius:"12px",
          fontWeight:700, fontSize:"15px", cursor:saving?"wait":"pointer", color:"#fff",
          background: saved?T.success:`linear-gradient(135deg,${T.accent},#4f46e5)`,
          opacity:!ready?0.5:1, boxShadow:"0 4px 16px rgba(124,58,237,0.3)",
        }}>{saving?"⏳ Saving...":saved?"✅ Saved!":"💾 Save as Image"}</button>

        <button onClick={doShare} disabled={saving||!ready} style={{
          padding:"13px 16px", background:T.surface, border:`1px solid ${T.border}`,
          color:T.text, borderRadius:"12px", fontWeight:700, fontSize:"15px",
          cursor:saving?"wait":"pointer", opacity:!ready?0.5:1,
        }}>📤 Share</button>
      </div>
    </>
  );
}

// ─── Disclaimer ───────────────────────────────────────────────────────────────
function Disclaimer({ onAccept }) {
  return (
    <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.95)", zIndex:1000,
      display:"flex", alignItems:"center", justifyContent:"center", padding:"20px" }}>
      <div style={{ background:T.surface, border:`1px solid ${T.danger}`, borderRadius:"16px",
        padding:"28px", maxWidth:"360px", width:"100%", textAlign:"center" }}>
        <div style={{ fontSize:"44px", marginBottom:"10px" }}>⚠️</div>
        <div style={{ color:T.danger, fontWeight:800, fontSize:"18px", marginBottom:"12px" }}>READ BEFORE CONTINUING</div>
        <p style={{ color:T.text, fontSize:"14px", lineHeight:1.6, marginBottom:"14px" }}>
          <strong>PrankForge</strong> is for <strong>fun & entertainment only</strong>.
        </p>
        <div style={{ background:"rgba(239,68,68,0.1)", border:"1px solid rgba(239,68,68,0.3)",
          borderRadius:"10px", padding:"14px", marginBottom:"18px", textAlign:"left" }}>
          {["❌ Do NOT use to defraud anyone","❌ Do NOT use for financial scams",
            "❌ Do NOT present as real documents","✅ All outputs carry a PRANK watermark",
            "✅ Share only with friends who know it's fake"].map((t,i)=>
            <div key={i} style={{ color:T.text, fontSize:"13px", marginBottom:"6px" }}>{t}</div>)}
        </div>
        <p style={{ color:T.muted, fontSize:"12px", marginBottom:"18px" }}>Misuse may be illegal. By continuing you confirm this is harmless fun only.</p>
        <button onClick={onAccept} style={{ width:"100%", padding:"14px", background:T.accent,
          color:"#fff", border:"none", borderRadius:"10px", fontWeight:700, fontSize:"15px", cursor:"pointer" }}>
          I Understand — Let's Prank! 😂
        </button>
      </div>
    </div>
  );
}

// ════════════════════════════════════════════════════════════════
// WHATSAPP GENERATOR
// ════════════════════════════════════════════════════════════════
function WhatsAppGen() {
  const ref = useRef();
  const [wmRemoved, setWmRemoved] = useState(false);
  const [showWmModal, setShowWmModal] = useState(false);
  const [contactName, setContactName] = useState("Bro Victor");
  const [contactAvatar, setContactAvatar] = useState(null);
  const [statusText, setStatusText] = useState("online");
  const [sbTime, setSbTime] = useState("6:22");
  const [wallpaper, setWallpaper] = useState("classic");
  const [groupMode, setGroupMode] = useState(false);
  const [msgs, setMsgs] = useState([
    { id:1, from:"them", text:"Guy I just saw you on TV 😭", time:"10:42 AM", read:true },
    { id:2, from:"me",   text:"Nah you're joking 😂",         time:"10:43 AM", read:true },
    { id:3, from:"them", text:"I swear! You were on channel 10 broadcast!", time:"10:43 AM", read:false },
  ]);
  const [newTxt, setNewTxt] = useState("");
  const [newFrom, setNewFrom] = useState("them");
  const [newTime, setNewTime] = useState("10:44 AM");
  const [newDate, setNewDate] = useState("");

  const addMsg = () => {
    if (!newTxt.trim()) return;
    setMsgs(p=>[...p,{id:Date.now(),from:newFrom,text:newTxt,time:newTime,date:newDate||null,read:true}]);
    setNewTxt(""); setNewDate("");
  };
  const removeMsg = id => setMsgs(p=>p.filter(m=>m.id!==id));

  return (
    <div>
      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:"10px", marginBottom:"12px" }}>
        <div><label style={lbl}>Contact Name</label><input value={contactName} onChange={e=>setContactName(e.target.value)} style={inp}/></div>
        <div><label style={lbl}>Status</label><input value={statusText} onChange={e=>setStatusText(e.target.value)} style={inp}/></div>
        <div><label style={lbl}>Clock Time</label><input value={sbTime} onChange={e=>setSbTime(e.target.value)} style={inp}/></div>
        <div><label style={lbl}>Wallpaper</label>
          <select value={wallpaper} onChange={e=>setWallpaper(e.target.value)} style={inp}>
            <option value="classic">Classic (default)</option>
            <option value="dark">Dark Mode</option>
          </select>
        </div>
        <div style={{ display:"flex", alignItems:"center", gap:"8px", paddingTop:"22px" }}>
          <input type="checkbox" checked={groupMode} onChange={e=>setGroupMode(e.target.checked)} id="grp" style={{ width:16,height:16 }}/>
          <label htmlFor="grp" style={{ color:T.text, fontSize:"13px", cursor:"pointer" }}>Group chat mode</label>
        </div>
      </div>

      <AvatarPicker label="Contact Photo" image={contactAvatar} onImage={setContactAvatar}
        initials={contactName.charAt(0).toUpperCase()} bgColor="#128c7e" />

      <div style={{ background:T.bg, border:`1px solid ${T.border}`, borderRadius:"10px", padding:"12px", marginBottom:"14px" }}>
        <div style={{ display:"flex", gap:"8px", marginBottom:"8px" }}>
          <select value={newFrom} onChange={e=>setNewFrom(e.target.value)} style={{ ...inp, flex:1 }}>
            <option value="them">{contactName} (left)</option>
            <option value="me">Me (right)</option>
          </select>
          <input value={newTime} onChange={e=>setNewTime(e.target.value)} style={{ ...inp, width:"90px" }} placeholder="Time"/>
        </div>
        <input value={newDate} onChange={e=>setNewDate(e.target.value)} style={{ ...inp, marginBottom:"8px" }} placeholder="Date separator e.g. Today (optional)"/>
        <div style={{ display:"flex", gap:"8px" }}>
          <input value={newTxt} onChange={e=>setNewTxt(e.target.value)} style={{ ...inp, flex:1 }}
            placeholder="Type message..." onKeyDown={e=>e.key==="Enter"&&addMsg()}/>
          <button onClick={addMsg} style={{ padding:"9px 18px", background:T.accent, color:"#fff",
            border:"none", borderRadius:"8px", fontWeight:700, fontSize:"14px", cursor:"pointer" }}>Add</button>
        </div>
      </div>

      {/* ── PREVIEW ── */}
      <div ref={ref} style={{ borderRadius:"14px", overflow:"hidden", boxShadow:"0 8px 32px rgba(0,0,0,0.5)", position:"relative" }}>
        <StatusBar time={sbTime} dark={wallpaper==="dark"}/>
        {/* Header */}
        <div style={{ background:wallpaper==="dark"?"#1f2c34":"#075e54", padding:"8px 12px", display:"flex", alignItems:"center", gap:"10px" }}>
          <span style={{ color:"rgba(255,255,255,0.7)", fontSize:"22px" }}>←</span>
          <div style={{ position:"relative" }}>
            <Avatar image={contactAvatar} size={38} initials={contactName.charAt(0).toUpperCase()} bgColor="#128c7e"/>
            <div style={{ position:"absolute", bottom:1, right:1, width:10, height:10,
              borderRadius:"50%", background:"#25d366", border:`1.5px solid ${wallpaper==="dark"?"#1f2c34":"#075e54"}` }}/>
          </div>
          <div style={{ flex:1 }}>
            <div style={{ color:"#fff", fontWeight:700, fontSize:"15px" }}>{contactName}</div>
            <div style={{ color:"rgba(255,255,255,0.75)", fontSize:"12px" }}>{statusText}</div>
          </div>
          <div style={{ display:"flex", gap:"14px", alignItems:"center" }}>
            <span style={{ color:"rgba(255,255,255,0.8)", fontSize:"18px" }}>📹</span>
            <span style={{ color:"rgba(255,255,255,0.8)", fontSize:"18px" }}>📞</span>
            <span style={{ color:"rgba(255,255,255,0.8)", fontSize:"20px" }}>⋮</span>
          </div>
        </div>
        {/* Chat */}
        <div style={{
          background: wallpaper==="dark" ? "#111b21" : "#e5ddd5",
          minHeight:"300px", padding:"10px 8px", display:"flex", flexDirection:"column", gap:"6px" }}>
          {msgs.map(msg=>(
            <div key={msg.id}>
              {msg.date && (
                <div style={{ textAlign:"center", margin:"8px 0" }}>
                  <span style={{ background:"rgba(255,255,255,0.85)", color:"#555",
                    fontSize:"11px", padding:"3px 12px", borderRadius:"8px",
                    boxShadow:"0 1px 2px rgba(0,0,0,0.15)" }}>{msg.date}</span>
                </div>
              )}
              <div style={{ display:"flex", justifyContent:msg.from==="me"?"flex-end":"flex-start", marginBottom:"2px" }}>
                <div style={{ position:"relative",
                  background: msg.from==="me"
                    ? (wallpaper==="dark"?"#005c4b":"#dcf8c6")
                    : (wallpaper==="dark"?"#1f2c34":"#ffffff"),
                  borderRadius: msg.from==="me"?"10px 2px 10px 10px":"2px 10px 10px 10px",
                  padding:"6px 10px 4px", maxWidth:"80%",
                  boxShadow:"0 1px 3px rgba(0,0,0,0.18)" }}>
                  {groupMode && msg.from==="them" && (
                    <div style={{ color:"#00a884", fontSize:"12px", fontWeight:700, marginBottom:"2px" }}>{contactName}</div>
                  )}
                  <div style={{ color: wallpaper==="dark"?"#e9edef":"#111", fontSize:"14px", lineHeight:1.45, wordBreak:"break-word" }}>{msg.text}</div>
                  <div style={{ display:"flex", alignItems:"center", justifyContent:"flex-end", gap:"3px", marginTop:"1px" }}>
                    <span style={{ color: wallpaper==="dark"?"#8696a0":"#999", fontSize:"10px" }}>{msg.time}</span>
                    {msg.from==="me" && <span style={{ fontSize:"12px", color:msg.read?(wallpaper==="dark"?"#53bdeb":"#34b7f1"):(wallpaper==="dark"?"#8696a0":"#999") }}>{msg.read?"✓✓":"✓"}</span>}
                  </div>
                  <button onClick={()=>removeMsg(msg.id)} style={{ position:"absolute", top:"-8px", right:"-8px",
                    background:T.danger, color:"#fff", border:"none", borderRadius:"50%",
                    width:"17px", height:"17px", fontSize:"10px", cursor:"pointer", lineHeight:1, zIndex:5 }}>×</button>
                </div>
              </div>
            </div>
          ))}
        </div>
        {/* Input bar */}
        <div style={{ background:wallpaper==="dark"?"#1f2c34":"#f0f0f0", padding:"6px 8px", display:"flex", alignItems:"center", gap:"8px" }}>
          <div style={{ flex:1, background:wallpaper==="dark"?"#2a3942":"#fff", borderRadius:"22px", padding:"9px 14px",
            fontSize:"14px", color:"#aaa", display:"flex", alignItems:"center", gap:"8px" }}>
            <span style={{ fontSize:"18px" }}>😊</span>
            <span style={{ flex:1 }}>Message</span>
            <span style={{ fontSize:"16px" }}>📎</span>
          </div>
          <div style={{ width:42, height:42, borderRadius:"50%", background:T.waGreen, flexShrink:0,
            display:"flex", alignItems:"center", justifyContent:"center", fontSize:"20px",
            boxShadow:"0 2px 8px rgba(37,211,102,0.4)" }}>🎤</div>
        </div>
        <WM removed={wmRemoved} onRemoveClick={()=>setShowWmModal(true)}/>
      </div>
      {showWmModal && <RemoveWMModal onClose={()=>setShowWmModal(false)} onRemoved={()=>setWmRemoved(true)} />}
      <SaveBar previewRef={ref} filename="whatsapp-prank" wmRemoved={wmRemoved} onWmRemoved={()=>setWmRemoved(true)} onOpenModal={()=>setShowWmModal(true)}/>
    </div>
  );
}

// ════════════════════════════════════════════════════════════════
// BANK RECEIPT GENERATORS — each bank has its own layout
// ════════════════════════════════════════════════════════════════

// Shared row for two-col table receipts
function Row({ label, value, labelColor="#555", bold=false, borderBottom=true, extra=null }) {
  return (
    <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start",
      padding:"10px 0", borderBottom:borderBottom?"1px solid #eee":"none" }}>
      <span style={{ color:labelColor, fontSize:"13px", minWidth:"120px", fontWeight:bold?700:400 }}>{label}</span>
      <div style={{ textAlign:"right", maxWidth:"65%" }}>
        <div style={{ color:"#111", fontSize:"13px", wordBreak:"break-all" }}>{value}</div>
        {extra && <div style={{ color:"#888", fontSize:"12px", marginTop:"2px" }}>{extra}</div>}
      </div>
    </div>
  );
}

// ── OPAY ──────────────────────────────────────────────────────────────────────
function OPayReceipt({ data }) {
  const DiagWM = () => (
    <div style={{ position:"absolute", inset:0, overflow:"hidden", pointerEvents:"none", zIndex:1 }}>
      {[...Array(7)].map((_,i)=>(
        <div key={i} style={{ position:"absolute", top:`${i*16-4}%`, left:"-10%", width:"130%",
          color:"rgba(0,177,64,0.06)", fontSize:"20px", fontWeight:800,
          whiteSpace:"nowrap", transform:"rotate(-25deg)", letterSpacing:"20px", userSelect:"none" }}>
          OPay OPay OPay OPay OPay OPay
        </div>
      ))}
    </div>
  );
  return (
    <div style={{ position:"relative", background:"#fff", fontFamily:"sans-serif", overflow:"hidden" }}>
      <DiagWM/>
      <div style={{ position:"relative", zIndex:2 }}>
        <div style={{ height:"13px", background:"radial-gradient(circle at 50% 0,transparent 5px,#f5f5f5 5px)", backgroundSize:"13px 13px", backgroundRepeat:"repeat-x" }}/>
        <div style={{ padding:"16px 20px", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
          <div style={{ display:"flex", alignItems:"center", gap:"6px" }}>
            <div style={{ width:26,height:26,borderRadius:"50%",border:"2.5px solid #00b140",display:"flex",alignItems:"center",justifyContent:"center" }}>
              <div style={{ width:12,height:12,borderRadius:"50%",background:"#00b140",display:"flex",alignItems:"center",justifyContent:"center" }}>
                <div style={{ width:4,height:4,borderRadius:"50%",background:"#fff" }}/>
              </div>
            </div>
            <span style={{ color:"#111", fontWeight:800, fontSize:"20px" }}><span style={{ color:"#00b140" }}>O</span>Pay</span>
          </div>
          <span style={{ color:"#333", fontSize:"15px" }}>Transaction Receipt</span>
        </div>
        <div style={{ width:"90%", margin:"0 auto", height:"1px", background:"#eee" }}/>
        <div style={{ textAlign:"center", padding:"20px 20px 14px" }}>
          <div style={{ color:"#00b140", fontSize:"34px", fontWeight:800 }}>₦{data.amount}</div>
          <div style={{ color:"#222", fontSize:"20px", fontWeight:500, marginTop:"4px" }}>{data.status}</div>
          <div style={{ color:"#999", fontSize:"13px", marginTop:"4px" }}>{data.dateTime}</div>
        </div>
        <div style={{ width:"90%", margin:"0 auto", height:"1px", background:"#eee", marginBottom:"12px" }}/>
        <div style={{ padding:"0 20px" }}>
          <Row label="Recipient Details" value={data.recipientName} extra={`${data.recipientBank} | ${data.recipientAcct}`}/>
          <Row label="Sender Details" value={data.senderName} extra={`${data.senderBank} | ${data.senderPhone}`}/>
          <Row label="Transaction No." value={data.txnNo}/>
          <Row label="Session ID" value={data.sessionId} borderBottom={false}/>
        </div>
        <div style={{ margin:"14px 20px", padding:"12px", background:"#f9f9f9", borderRadius:"6px", fontSize:"11px", color:"#777", lineHeight:1.6 }}>
          Enjoy a better life with OPay. Get free transfers, withdrawals, bill payments, instant loans, and good annual interest on your savings. OPay is licensed by the Central Bank of Nigeria and insured by the NDIC.
        </div>
        <div style={{ height:"13px", background:"radial-gradient(circle at 50% 100%,transparent 5px,#f5f5f5 5px)", backgroundSize:"13px 13px", backgroundRepeat:"repeat-x" }}/>
      </div>
    </div>
  );
}

// ── FIRSTBANK ─────────────────────────────────────────────────────────────────
function FirstBankReceipt({ data }) {
  const DiagWM = () => (
    <div style={{ position:"absolute", inset:0, overflow:"hidden", pointerEvents:"none", zIndex:1 }}>
      {[...Array(5)].map((_,i)=>(
        <div key={i} style={{ position:"absolute", top:`${i*22-5}%`, left:"-5%", width:"120%",
          color:"rgba(0,75,141,0.04)", fontSize:"36px", fontWeight:800,
          whiteSpace:"nowrap", transform:"rotate(-30deg)", letterSpacing:"10px", userSelect:"none" }}>
          FirstBank FirstBank FirstBank
        </div>
      ))}
      {/* decorative left side blocks */}
      {[0,1,2,3].map(i=>(
        <div key={i} style={{ position:"absolute", left:0, top:`${i*25}%`, width:"28px",
          height:"60px", background:`rgba(0,75,141,${0.05+i*0.02})`, borderRadius:"0 4px 4px 0" }}/>
      ))}
    </div>
  );
  return (
    <div style={{ position:"relative", background:"#fff", fontFamily:"sans-serif", overflow:"hidden" }}>
      <DiagWM/>
      <div style={{ position:"relative", zIndex:2, padding:"20px 24px" }}>
        {/* Logo row */}
        <div style={{ display:"flex", justifyContent:"flex-end", marginBottom:"20px" }}>
          <div style={{ display:"flex", alignItems:"center", gap:"6px" }}>
            <div style={{ width:32,height:32,borderRadius:"50%",background:"#004B8D",display:"flex",alignItems:"center",justifyContent:"center" }}>
              <span style={{ color:"#fff", fontSize:"18px" }}>🦅</span>
            </div>
            <div>
              <div style={{ color:"#004B8D", fontWeight:800, fontSize:"16px" }}>FirstBank</div>
              <div style={{ color:"#999", fontSize:"9px" }}>Since 1894</div>
            </div>
          </div>
        </div>
        {/* Title */}
        <div style={{ textAlign:"center", marginBottom:"6px" }}>
          <div style={{ color:"#222", fontWeight:700, fontSize:"18px" }}>Transaction Receipt</div>
          <div style={{ color:"#004B8D", fontWeight:700, fontSize:"16px", marginTop:"4px" }}>{data.status}</div>
          <div style={{ color:"#004B8D", fontSize:"28px", fontWeight:800, marginTop:"6px" }}>₦ {data.amount}</div>
          <div style={{ color:"#888", fontSize:"12px", marginTop:"4px" }}>{data.amountWords}</div>
          <div style={{ color:"#888", fontSize:"12px" }}>{data.dateTime}</div>
        </div>
        <div style={{ height:"1px", background:"#ddd", margin:"14px 0" }}/>
        {/* Rows — orange bold labels */}
        {[
          ["From:", data.fromAcct],
          ["Sender Name:", data.senderName],
          ["Beneficiary Name:", data.recipientName],
          ["Account No:", data.recipientAcct],
          ["Bank:", data.recipientBank],
          ["Transaction Type:", data.txnType],
          ["Reference No:", data.txnNo],
          ["Narration:", data.narration||"None"],
        ].map(([l,v])=>(
          <div key={l} style={{ display:"flex", padding:"8px 0", borderBottom:"1px solid #f5f5f5" }}>
            <span style={{ color:"#004B8D", fontWeight:700, fontSize:"13px", minWidth:"150px" }}>{l}</span>
            <span style={{ color:"#111", fontSize:"13px", wordBreak:"break-all" }}>{v}</span>
          </div>
        ))}
        <div style={{ marginTop:"16px", fontSize:"10px", color:"#888", lineHeight:1.7 }}>
          For more information, please contact us: 01-9194885838, 07080625000 findcontactcomplaints@firstbanknigeria.com complaints@firstbanknigeria.com; www.firstbanknigeria.com
        </div>
        <div style={{ marginTop:"12px", padding:"10px", background:"#f0f7ff", borderRadius:"6px" }}>
          <div style={{ color:"#004B8D", fontWeight:700, fontSize:"13px" }}>Get airtime in seconds by dialing *894*Amount#</div>
          <div style={{ color:"#555", fontSize:"12px" }}>Out of Data? Dial *894*2# to get data now.</div>
        </div>
        <div style={{ marginTop:"10px", fontSize:"9px", color:"#aaa", lineHeight:1.6 }}>
          Your transfer has been successful and the beneficiary's account will be credited. However, this does not serve as confirmation of a credit into the beneficiary's account. Due to the nature of the interac transactions may be subject to the interruption, transmission blackout, delayed transmission and incorrect data transmission. The bank is not liable to malfunctions in communications facilities not within its control to confirm that may affect the accuracy or timeliness of messages and transactions you send. All transactions are subject to verification and normal fraud checks.
        </div>
      </div>
    </div>
  );
}

// ── GTBANK ────────────────────────────────────────────────────────────────────
function GTBankReceipt({ data }) {
  const DiagWM = () => (
    <div style={{ position:"absolute", inset:0, overflow:"hidden", pointerEvents:"none", zIndex:1 }}>
      {[...Array(6)].map((_,i)=>(
        <div key={i} style={{ position:"absolute", top:`${i*18-4}%`, left:"-10%", width:"130%",
          color:"rgba(242,101,34,0.05)", fontSize:"22px", fontWeight:800,
          whiteSpace:"nowrap", transform:"rotate(-20deg)", letterSpacing:"16px", userSelect:"none" }}>
          Guaranty Trust Bank plc RC 152321 Guaranty Trust Bank plc
        </div>
      ))}
    </div>
  );
  return (
    <div style={{ position:"relative", background:"#fff", fontFamily:"Arial,sans-serif", overflow:"hidden" }}>
      <DiagWM/>
      <div style={{ position:"relative", zIndex:2, padding:"20px 24px" }}>
        {/* GTB logo block top-right */}
        <div style={{ display:"flex", justifyContent:"flex-end", marginBottom:"16px" }}>
          <div style={{ textAlign:"right" }}>
            <div style={{ background:"#f26522", color:"#fff", fontWeight:800, fontSize:"16px",
              padding:"8px 12px", borderRadius:"4px", display:"inline-block" }}>GTBank</div>
            <div style={{ color:"#555", fontSize:"11px", marginTop:"4px" }}>Guaranty Trust Bank plc</div>
            <div style={{ color:"#999", fontSize:"10px" }}>RC 152321</div>
          </div>
        </div>
        {/* Title with lines */}
        <div style={{ display:"flex", alignItems:"center", gap:"10px", marginBottom:"18px" }}>
          <div style={{ flex:1, height:"1px", background:"#ccc" }}/>
          <div style={{ color:"#222", fontWeight:700, fontSize:"17px" }}>Transaction Receipt</div>
          <div style={{ flex:1, height:"1px", background:"#ccc" }}/>
        </div>
        {/* Rows — orange bold labels */}
        {[
          ["Transaction Date:", data.dateTime],
          ["Reference Number:", data.txnNo],
          ["Sender:", data.senderName],
          ["Transaction Amount:", `${data.amount}NGN`],
          ["Amount In Words:", data.amountWords],
          ["Transaction Type:", data.txnType||"To Other Bank (Instant)"],
          ["Receiver:", `${data.recipientName} - ${data.recipientAcct} - ${data.recipientBankCode||"FBN"}`],
          ["Account Number:", data.recipientAcct],
          ["Receiving Bank:", data.recipientBank],
          ["Remarks:", data.narration||""],
        ].map(([l,v])=>(
          <div key={l} style={{ display:"flex", padding:"9px 0", borderBottom:"1px solid #f0f0f0" }}>
            <span style={{ color:"#f26522", fontWeight:700, fontSize:"13px", minWidth:"170px", flexShrink:0 }}>{l}</span>
            <span style={{ color:"#111", fontSize:"13px", wordBreak:"break-all" }}>{v}</span>
          </div>
        ))}
        <div style={{ height:"1px", background:"#ccc", margin:"20px 0 14px" }}/>
        <div style={{ fontSize:"10px", color:"#888", lineHeight:1.7, marginBottom:"16px" }}>
          <strong>DISCLAIMER</strong><br/>
          Your transfer has been successful and the beneficiary's account will be credited. However, this does not serve as confirmation of credit into the beneficiary's account. Due to the nature of the Internet, transactions may be subject to interruption, transmission blackout, delayed transmission and incorrect data transmission. The Bank is not liable for malfunctions in communications facilities not within its control that may affect the accuracy or timeliness of messages and transactions you send. All transactions are subject to verification and our normal fraud checks
        </div>
        <div style={{ textAlign:"center", color:"#333", fontWeight:700, fontSize:"13px" }}>Generated from GTWorld</div>
      </div>
    </div>
  );
}

// ── KUDA ──────────────────────────────────────────────────────────────────────
function KudaReceipt({ data }) {
  return (
    <div style={{ background:"#fff", fontFamily:"'Helvetica Neue',Arial,sans-serif", padding:"24px" }}>
      {/* Header */}
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:"28px" }}>
        <div style={{ display:"flex", alignItems:"center", gap:"6px" }}>
          <div style={{ width:32,height:32,borderRadius:"6px",background:"#40196d",display:"flex",alignItems:"center",justifyContent:"center" }}>
            <span style={{ color:"#fff", fontWeight:900, fontSize:"14px" }}>K</span>
          </div>
          <span style={{ color:"#40196d", fontWeight:900, fontSize:"22px" }}>kuda.</span>
        </div>
        <span style={{ color:"#333", fontSize:"15px", fontWeight:500 }}>Transaction Details</span>
      </div>
      {/* Amount */}
      <div style={{ textAlign:"center", marginBottom:"28px" }}>
        <div style={{ color:"#555", fontSize:"13px", fontWeight:600, marginBottom:"6px" }}>Transaction Amount</div>
        <div style={{ color:"#40196d", fontSize:"36px", fontWeight:800 }}>₦{data.amount}</div>
      </div>
      {/* Detail rows */}
      {[
        ["Beneficiary Details", data.recipientName, `${data.recipientBank} | ${data.recipientAcct}`],
        ["Sender Details", data.senderName, `${data.senderBank||"Kuda"} | ${data.txnNo}`],
        ["Paid On", data.dateTime, data.time||""],
        ["Fees", "₦0.00", null],
        ["Description", data.narration||`From ${data.senderName}`, null],
        ["Transaction Reference", data.txnNo, null],
        ["Payment Type", data.txnType||"Local Funds Transfer", null],
      ].map(([l,v,sub])=>(
        <div key={l} style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start",
          padding:"12px 0", borderBottom:"1px solid #f0f0f0" }}>
          <span style={{ color:"#aaa", fontSize:"13px" }}>{l}</span>
          <div style={{ textAlign:"right", maxWidth:"60%" }}>
            <div style={{ color:"#111", fontSize:"13px", fontWeight:500, wordBreak:"break-all" }}>{v}</div>
            {sub && <div style={{ color:"#aaa", fontSize:"11px", marginTop:"2px", wordBreak:"break-all" }}>{sub}</div>}
          </div>
        </div>
      ))}
      {/* CTA */}
      <div style={{ marginTop:"24px", background:"#f5f0ff", borderRadius:"12px", padding:"14px 16px",
        display:"flex", alignItems:"center", gap:"12px" }}>
        <div style={{ width:36,height:36,borderRadius:"8px",background:"#40196d",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0 }}>
          <span style={{ color:"#fff", fontWeight:900, fontSize:"14px" }}>K.</span>
        </div>
        <div style={{ color:"#40196d", fontWeight:700, fontSize:"13px" }}>Not on Kuda? Tap here to download the money app for Africans</div>
      </div>
      {/* Footer */}
      <div style={{ marginTop:"20px", textAlign:"center", fontSize:"10px", color:"#aaa", lineHeight:1.7 }}>
        © 2023 Kuda Technologies Ltd (Company No. 11472232). All rights reserved.<br/>
        Nigerian banking services offered by Kuda Microfinance Bank (RC796975) with registered address at 151 - Herbert Macaulay Way, Yaba, Lagos, Nigeria.
      </div>
    </div>
  );
}

// ── MONIEPOINT ────────────────────────────────────────────────────────────────
function MoniepointReceipt({ data }) {
  return (
    <div style={{ background:"linear-gradient(135deg,#1a6bcc,#1a4fa8)", padding:"24px 16px", minHeight:"500px", position:"relative" }}>
      {/* Decorative yellow ribbon */}
      <div style={{ position:"absolute", top:"40%", left:"-10px", width:"calc(100% + 20px)",
        height:"8px", background:"#f5a623", opacity:0.5, transform:"rotate(-2deg)" }}/>
      <div style={{ position:"absolute", top:"80%", left:"-10px", width:"calc(100% + 20px)",
        height:"6px", background:"#f5a623", opacity:0.3, transform:"rotate(1deg)" }}/>
      {/* Logo */}
      <div style={{ display:"flex", justifyContent:"center", alignItems:"center", gap:"8px", marginBottom:"20px" }}>
        <div style={{ width:32,height:32,borderRadius:"8px",background:"#fff",display:"flex",alignItems:"center",justifyContent:"center" }}>
          <span style={{ color:"#1a6bcc", fontWeight:900, fontSize:"14px" }}>M</span>
        </div>
        <span style={{ color:"#fff", fontWeight:800, fontSize:"20px" }}>Moniepoint</span>
      </div>
      {/* Card */}
      <div style={{ background:"#fff", borderRadius:"16px 16px 0 0",
        paddingBottom:"0", overflow:"hidden",
        boxShadow:"0 4px 20px rgba(0,0,0,0.2)" }}>
        {/* Debit header */}
        <div style={{ padding:"16px 20px 0" }}>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start" }}>
            <div>
              <span style={{ background:"#e8f4ff", color:"#1a6bcc", fontSize:"11px", fontWeight:700,
                padding:"3px 10px", borderRadius:"4px" }}>DEBIT</span>
              <div style={{ color:"#111", fontSize:"28px", fontWeight:800, marginTop:"8px" }}>₦{data.amount}</div>
            </div>
            <div style={{ width:38,height:38,borderRadius:"8px",background:"#1a6bcc",display:"flex",alignItems:"center",justifyContent:"center" }}>
              <span style={{ color:"#fff", fontWeight:900, fontSize:"16px" }}>M</span>
            </div>
          </div>
        </div>
        <div style={{ height:"1px", background:"#f0f0f0", margin:"14px 0" }}/>
        {/* Detail rows */}
        <div style={{ padding:"0 20px 20px" }}>
          {[
            ["Transaction Type", <span style={{ background:"#e8f4ff", color:"#1a6bcc", fontSize:"11px", fontWeight:700, padding:"2px 8px", borderRadius:"4px" }}>Transfer</span>],
            ["Sender Name", data.senderName],
            ["Source Institution", data.senderBank||"Moniepoint MFB"],
            ["Beneficiary", data.recipientName],
            ["Beneficiary Institution", data.recipientBank||"Moniepoint MFB"],
            ["Transaction Date", data.dateTime],
            ["Transaction Reference", data.txnNo],
            ["Business Name", data.businessName||data.senderName],
          ].map(([l,v])=>(
            <div key={l} style={{ marginBottom:"14px" }}>
              <div style={{ color:"#aaa", fontSize:"11px", marginBottom:"3px" }}>{l}</div>
              <div style={{ color:"#111", fontSize:"14px", fontWeight:500 }}>{v}</div>
            </div>
          ))}
        </div>
        {/* Scalloped bottom */}
        <div style={{ height:"20px",
          background:"radial-gradient(circle at 50% 100%,#1a6bcc 8px,#fff 8px)",
          backgroundSize:"20px 20px", backgroundRepeat:"repeat-x", backgroundPosition:"bottom" }}/>
      </div>
    </div>
  );
}

// ── ACCESS BANK ───────────────────────────────────────────────────────────────
function AccessReceipt({ data }) {
  return (
    <div style={{ background:"#fff", fontFamily:"Arial,sans-serif", padding:"28px 28px 20px" }}>
      {/* Header */}
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:"20px" }}>
        <div style={{ display:"flex", alignItems:"center", gap:"8px" }}>
          <div style={{ width:36,height:36,borderRadius:"50%",border:"2px solid #e30613",display:"flex",alignItems:"center",justifyContent:"center" }}>
            <span style={{ color:"#e30613", fontSize:"16px" }}>◆</span>
          </div>
          <span style={{ color:"#003087", fontWeight:700, fontSize:"22px" }}>access</span>
        </div>
        <div style={{ textAlign:"right" }}>
          <div style={{ color:"#e30613", fontWeight:700, fontSize:"28px", lineHeight:1 }}>/</div>
          <div style={{ color:"#e30613", fontSize:"11px", fontWeight:600 }}>more than banking</div>
        </div>
      </div>
      <div style={{ textAlign:"center", marginBottom:"6px" }}>
        <div style={{ color:"#003087", fontWeight:800, fontSize:"20px" }}>Transaction Receipt</div>
        <div style={{ color:"#999", fontSize:"11px", marginTop:"4px" }}>Generated from AccessMore on {data.dateTime}</div>
      </div>
      <div style={{ height:"1px", background:"#ddd", margin:"16px 0" }}/>
      {[
        ["Transaction Amount", data.amount.includes("N")?data.amount:`N${data.amount}`],
        ["Transaction Type", data.txnType||"INTER-BANK"],
        ["Transaction Date", data.dateTime],
        ["Sender", data.senderName],
        ["Beneficiary", `${data.recipientName}\n${data.recipientAcct}\n${data.recipientBank}`],
        ["Remark", data.narration||""],
        ["Transaction Reference", data.txnNo],
        ["Transaction Status", "Transfer Request Successful"],
      ].map(([l,v])=>(
        <div key={l} style={{ display:"flex", padding:"10px 0", borderBottom:"1px solid #f5f5f5" }}>
          <span style={{ color:"#f26522", fontWeight:700, fontSize:"13px", minWidth:"170px", flexShrink:0 }}>{l}</span>
          <span style={{ color:"#003087", fontSize:"13px", whiteSpace:"pre-line", wordBreak:"break-all" }}>{v}</span>
        </div>
      ))}
      <div style={{ marginTop:"18px", fontSize:"10px", color:"#888", lineHeight:1.7 }}>
        If you have any questions or would like more information, please call our 24-hour Contact Centre on <span style={{ color:"#003087" }}>0700CallAccess</span>, <span style={{ color:"#003087" }}>0700 3000000</span>, <span style={{ color:"#003087" }}>+234 1-2712005-7</span>, <span style={{ color:"#003087" }}>+234 1-2802500</span> or send an email to <span style={{ color:"#003087" }}>contactcenter@accessbankplc.com</span><br/>
        Thank you for choosing Access Bank.<br/><br/>
        Banking with Access: Branch | ATM | Online | Mobile | Contact centre
      </div>
    </div>
  );
}

// ── FIDELITY ──────────────────────────────────────────────────────────────────
function FidelityReceipt({ data }) {
  return (
    <div style={{ background:"#fff", fontFamily:"Arial,sans-serif", padding:"28px" }}>
      {/* Logo */}
      <div style={{ display:"flex", justifyContent:"flex-end", marginBottom:"20px" }}>
        <div style={{ display:"flex", alignItems:"center", gap:"4px" }}>
          <div style={{ width:28,height:28,display:"flex",flexDirection:"column",overflow:"hidden",borderRadius:"2px" }}>
            <div style={{ flex:1, background:"#003087" }}/>
            <div style={{ flex:1, background:"#00a651" }}/>
          </div>
          <span style={{ color:"#003087", fontWeight:800, fontSize:"20px" }}>Fidelity</span>
        </div>
      </div>
      <div style={{ marginBottom:"4px" }}>
        <div style={{ color:"#111", fontWeight:800, fontSize:"20px" }}>Online Banking</div>
        <div style={{ color:"#555", fontSize:"13px" }}>Transaction Receipt</div>
      </div>
      <div style={{ height:"1px", background:"#ddd", margin:"14px 0" }}/>
      {[
        ["Payer", `${data.senderName}\n${data.fromAcct||"560****654"}\nFidelity Bank Plc.`],
        ["Receiver", `${data.recipientName}\n${data.recipientAcct}\n${data.recipientBank}`],
        ["Transaction", `NGN ${data.amount}\nINTERTRANSFER\n${data.dateTime}`],
        ["Narration", data.narration||`COB TRF TO ${data.recipientName}`],
        ["Reference", `${data.txnNo}\nSUCCESSFUL`],
      ].map(([l,v])=>(
        <div key={l} style={{ display:"flex", padding:"11px 0", borderBottom:"1px solid #eee" }}>
          <span style={{ color:"#555", fontSize:"13px", minWidth:"110px", flexShrink:0 }}>{l}</span>
          <span style={{ color:"#111", fontSize:"13px", whiteSpace:"pre-line", wordBreak:"break-all" }}>{v}</span>
        </div>
      ))}
      {/* QR + disclaimer */}
      <div style={{ display:"flex", gap:"16px", marginTop:"18px", alignItems:"flex-start" }}>
        <div style={{ width:64,height:64,background:"#000",flexShrink:0,display:"flex",alignItems:"center",justifyContent:"center" }}>
          <div style={{ width:56,height:56,background:"#fff",display:"grid",gridTemplateColumns:"repeat(7,1fr)",gap:"1px",padding:"4px" }}>
            {[...Array(49)].map((_,i)=><div key={i} style={{ background:Math.random()>0.5?"#000":"#fff" }}/>)}
          </div>
        </div>
        <div style={{ fontSize:"11px", color:"#555", lineHeight:1.7 }}>
          This is an electronic receipt of a transaction and does not require any signature. The authenticity of transaction can be confirmed with the Bank.<br/>
          For any other assistance, kindly call True Serve on 0700 3233 5489 or email true.serve@fidelitybank.ng
        </div>
      </div>
      <div style={{ marginTop:"22px", borderTop:"2px solid #00a651", paddingTop:"12px" }}>
        <div style={{ color:"#00a651", fontWeight:700, fontSize:"14px" }}>Bank With IVY On WhatsApp</div>
        <div style={{ color:"#555", fontSize:"12px" }}>Chat with IVY today on <strong>09030000302</strong> to get your banking needs sorted instantly</div>
      </div>
    </div>
  );
}

// ── MTN MoMo ──────────────────────────────────────────────────────────────────
function MoMoReceipt({ data }) {
  return (
    <div style={{ background:"#fff", fontFamily:"Arial,sans-serif" }}>
      {/* Header */}
      <div style={{ display:"flex", justifyContent:"flex-end", padding:"20px 24px 10px" }}>
        <div style={{ display:"flex", alignItems:"center", gap:"6px" }}>
          <div style={{ width:36,height:36,borderRadius:"50%",background:"#ffcc00",display:"flex",alignItems:"center",justifyContent:"center" }}>
            <span style={{ fontSize:"20px" }}>M</span>
          </div>
          <div>
            <div style={{ color:"#009fdb", fontWeight:800, fontSize:"16px" }}>MoMo</div>
            <div style={{ color:"#999", fontSize:"9px" }}>from MTN</div>
          </div>
        </div>
      </div>
      <div style={{ padding:"0 24px 20px" }}>
        <div style={{ color:"#111", fontWeight:800, fontSize:"20px", marginBottom:"20px" }}>Transaction Receipt</div>
        {[
          ["Date and Time:", data.dateTime],
          ["Recipient Name:", data.recipientName],
          ["Recipient Number:", data.recipientAcct],
          ["Sender:", data.senderName],
          ["Amount:", `GHS ${data.amount}`],
          ["Transaction ID:", data.txnNo],
          ["Transaction Type:", "MoMo wallet"],
          ["Status:", data.status||"Successful"],
        ].map(([l,v])=>(
          <div key={l} style={{ display:"flex", padding:"10px 0", borderBottom:"1px solid #f5f5f5" }}>
            <span style={{ color:"#111", fontWeight:700, fontSize:"13px", minWidth:"160px", flexShrink:0 }}>{l}</span>
            <span style={{ color:"#333", fontSize:"13px" }}>{v}</span>
          </div>
        ))}
        <div style={{ marginTop:"20px", fontSize:"11px", color:"#777", lineHeight:1.8 }}>
          If you need more information or have any questions about this payment, please contact the sender.<br/>
          Please check your account to confirm you have received this payment.
        </div>
        <div style={{ marginTop:"16px" }}>
          <div style={{ color:"#111", fontWeight:700, fontSize:"12px" }}>Disclaimer</div>
          <div style={{ fontSize:"10px", color:"#888", lineHeight:1.7, marginTop:"6px" }}>
            Your transaction has been successfully processed and the beneficiary's account will be credited. The completion of any transfer/transaction is subject to other factors including (but not limited to) transaction errors, delayed transmission, incomplete information, interruptions, transmission blackout, fluctuations on the network/internet, glitch, delayed information, or other circumstances beyond the control of MoMo which may impact on the transaction and for which MoMo is not liable.
          </div>
          <div style={{ marginTop:"12px", fontSize:"11px", color:"#555" }}>Yours sincerely,<br/><strong>The MoMo Team</strong></div>
        </div>
      </div>
      {/* Yellow footer */}
      <div style={{ background:"#ffcc00", padding:"10px 24px", textAlign:"center" }}>
        <div style={{ fontSize:"10px", color:"#333", fontWeight:600 }}>MTN (PTY) LTD is an authorised Financial Service Provider. FSP license number: 44774</div>
        <div style={{ fontSize:"10px", color:"#333" }}>Website: https://www.momo.mtn.com</div>
      </div>
    </div>
  );
}

// ── RECEIPT CONTROLLER ────────────────────────────────────────────────────────
function PaymentGen() {
  const ref = useRef();
  const [wmRemoved, setWmRemoved] = useState(false);
  const [showWmModal, setShowWmModal] = useState(false);
  const BANKS = [
    { id:"opay",       name:"OPay" },
    { id:"firstbank",  name:"FirstBank" },
    { id:"gtbank",     name:"GTBank" },
    { id:"kuda",       name:"Kuda Bank" },
    { id:"moniepoint", name:"Moniepoint" },
    { id:"access",     name:"Access Bank" },
    { id:"fidelity",   name:"Fidelity Bank" },
    { id:"momo",       name:"MTN MoMo" },
  ];
  const [bank, setBank] = useState("opay");
  const [data, setData] = useState({
    amount:"50,000.00", amountWords:"Fifty Thousand Naira Only",
    status:"Successful", dateTime:"Jun 22, 2026 10:42:10",
    recipientName:"SAMUEL IZUCHUKWU NWOKOMA", recipientAcct:"9059263212",
    recipientBank:"PAYCOM (OPAY)", recipientBankCode:"OPY",
    senderName:"VICTOR ALI AGBO", senderBank:"OPay", senderPhone:"803****907",
    fromAcct:"****38688", txnType:"Interbank Transfer",
    txnNo:"260621020100674293775464", sessionId:"100004260621140627163217994845",
    narration:"None", businessName:"", time:"10:42 AM",
  });
  const set = (k,v) => setData(d=>({...d,[k]:v}));

  const fields = [
    ["Amount", "amount"], ["Amount in Words", "amountWords"],
    ["Status", "status"], ["Date & Time", "dateTime"],
    ["Recipient Name", "recipientName"], ["Recipient Bank", "recipientBank"],
    ["Recipient Acct", "recipientAcct"], ["Sender Name", "senderName"],
    ["Sender Bank", "senderBank"], ["Sender Phone/Acct", "senderPhone"],
    ["From (masked)", "fromAcct"], ["Transaction Type", "txnType"],
    ["Reference / Txn No.", "txnNo"], ["Session ID", "sessionId"],
    ["Narration", "narration"],
  ];

  const renderReceipt = () => {
    if (bank==="opay")       return <OPayReceipt data={data}/>;
    if (bank==="firstbank")  return <FirstBankReceipt data={data}/>;
    if (bank==="gtbank")     return <GTBankReceipt data={data}/>;
    if (bank==="kuda")       return <KudaReceipt data={data}/>;
    if (bank==="moniepoint") return <MoniepointReceipt data={data}/>;
    if (bank==="access")     return <AccessReceipt data={data}/>;
    if (bank==="fidelity")   return <FidelityReceipt data={data}/>;
    if (bank==="momo")       return <MoMoReceipt data={data}/>;
  };

  return (
    <div>
      <div style={{ marginBottom:"14px" }}>
        <label style={lbl}>Select Bank / Wallet</label>
        <div style={{ display:"flex", flexWrap:"wrap", gap:"8px" }}>
          {BANKS.map(b=>(
            <button key={b.id} onClick={()=>setBank(b.id)} style={{
              padding:"7px 14px", borderRadius:"20px", border:`1.5px solid ${bank===b.id?T.accent:T.border}`,
              background: bank===b.id?T.accentGlow:"transparent",
              color: bank===b.id?T.accentLight:T.muted,
              fontWeight: bank===b.id?700:400, fontSize:"13px", cursor:"pointer",
            }}>{b.name}</button>
          ))}
        </div>
      </div>
      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:"10px", marginBottom:"16px" }}>
        {fields.map(([label,key])=>(
          <div key={key}>
            <label style={lbl}>{label}</label>
            <input value={data[key]} onChange={e=>set(key,e.target.value)} style={inp}/>
          </div>
        ))}
      </div>
      {/* Preview */}
      <div ref={ref} style={{ position:"relative", borderRadius:"8px", overflow:"hidden",
        boxShadow:"0 8px 32px rgba(0,0,0,0.35)" }}>
        {renderReceipt()}
        <WM removed={wmRemoved} onRemoveClick={()=>setShowWmModal(true)}/>
      </div>
      {showWmModal && <RemoveWMModal onClose={()=>setShowWmModal(false)} onRemoved={()=>setWmRemoved(true)} />}
      <SaveBar previewRef={ref} filename={`${bank}-receipt-prank`} wmRemoved={wmRemoved} onWmRemoved={()=>setWmRemoved(true)} onOpenModal={()=>setShowWmModal(true)}/>
    </div>
  );
}

// ════════════════════════════════════════════════════════════════
// FACEBOOK GENERATOR
// ════════════════════════════════════════════════════════════════
function FacebookGen() {
  const ref = useRef();
  const imgRef = useRef();
  const [wmRemoved, setWmRemoved] = useState(false);
  const [showWmModal, setShowWmModal] = useState(false);
  const [name, setName]         = useState("Mega Reigns");
  const [avatar, setAvatar]     = useState(null);
  const [postText, setPostText] = useState("I just withdrew 3.4 million.\n\nThis is for my Sunday's lunch 😂💰");
  const [time, setTime]         = useState("17h");
  const [likes, setLikes]       = useState("1.2K");
  const [comments, setComments] = useState("348");
  const [shares, setShares]     = useState("89");
  const [verified, setVerified] = useState(false);
  const [postImage, setPostImage] = useState(null);
  const [statusTime, setStatusTime] = useState("6:23");
  const [notifCount, setNotifCount] = useState("15+");
  const [fakeComments, setFakeComments] = useState([
    { id:1, name:"Chisom Blessing", text:"Congratulations bro! 🎉🎊", time:"1h", avatar:null },
    { id:2, name:"Emeka Okafor",    text:"This guy ehn 😂😂 God when", time:"45m", avatar:null },
    { id:3, name:"Sandra Nwosu",    text:"You too much! Treat us o 🙏❤️", time:"20m", avatar:null },
  ]);
  const [newCmt, setNewCmt]   = useState("");
  const [newCmtName, setNewCmtName] = useState("");
  const addComment = () => {
    if (!newCmt.trim()||!newCmtName.trim()) return;
    setFakeComments(p=>[...p,{ id:Date.now(), name:newCmtName, text:newCmt, time:"Just now", avatar:null }]);
    setNewCmt(""); setNewCmtName("");
  };
  const removeComment = id => setFakeComments(p=>p.filter(c=>c.id!==id));

  const handlePostImg = e => {
    const f=e.target.files[0]; if(!f) return;
    const r=new FileReader(); r.onload=ev=>setPostImage(ev.target.result); r.readAsDataURL(f);
  };
  const avatarBg = `hsl(${name.charCodeAt(0)*17%360},55%,42%)`;

  return (
    <div>
      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:"10px", marginBottom:"12px" }}>
        <div><label style={lbl}>Full Name</label><input value={name} onChange={e=>setName(e.target.value)} style={inp}/></div>
        <div><label style={lbl}>Time Ago</label><input value={time} onChange={e=>setTime(e.target.value)} style={inp}/></div>
        <div><label style={lbl}>Likes</label><input value={likes} onChange={e=>setLikes(e.target.value)} style={inp}/></div>
        <div><label style={lbl}>Comments</label><input value={comments} onChange={e=>setComments(e.target.value)} style={inp}/></div>
        <div><label style={lbl}>Shares</label><input value={shares} onChange={e=>setShares(e.target.value)} style={inp}/></div>
        <div><label style={lbl}>Clock Time</label><input value={statusTime} onChange={e=>setStatusTime(e.target.value)} style={inp}/></div>
        <div><label style={lbl}>Notif Badge</label><input value={notifCount} onChange={e=>setNotifCount(e.target.value)} style={inp}/></div>
        <div style={{ display:"flex", alignItems:"center", gap:"8px", paddingTop:"22px" }}>
          <input type="checkbox" checked={verified} onChange={e=>setVerified(e.target.checked)} id="vfy" style={{ width:16,height:16 }}/>
          <label htmlFor="vfy" style={{ color:T.text, fontSize:"13px", cursor:"pointer" }}>Verified ✓</label>
        </div>
      </div>
      <div style={{ marginBottom:"12px" }}>
        <label style={lbl}>Post Text</label>
        <textarea value={postText} onChange={e=>setPostText(e.target.value)}
          style={{ ...inp, minHeight:"80px", resize:"vertical", fontFamily:"inherit" }}/>
      </div>

      {/* Avatar picker outside preview */}
      <AvatarPicker label="Profile Photo" image={avatar} onImage={setAvatar}
        initials={name.charAt(0)} bgColor={avatarBg}/>

      {/* Post image */}
      <div onClick={()=>imgRef.current.click()} style={{
        background:T.bg, border:`1px dashed ${T.border}`, borderRadius:"10px",
        padding:"14px", textAlign:"center", cursor:"pointer", marginBottom:"14px" }}>
        <div style={{ fontSize:"22px", marginBottom:"4px" }}>{postImage?"🖼️ ✅":"🖼️"}</div>
        <div style={{ color:T.muted, fontSize:"13px" }}>{postImage?"Post image set — tap to change":"Add post image (optional)"}</div>
        <input ref={imgRef} type="file" accept="image/*" onChange={handlePostImg} style={{ display:"none" }}/>
      </div>

      {/* PREVIEW */}
      <div ref={ref} style={{ overflow:"hidden", boxShadow:"0 8px 32px rgba(0,0,0,0.4)", fontFamily:"Helvetica,Arial,sans-serif" }}>
        <StatusBar time={statusTime} dark={false}/>
        {/* FB nav */}
        <div style={{ background:"#fff", padding:"6px 14px", display:"flex", alignItems:"center",
          justifyContent:"space-between", borderBottom:"1px solid #ddd" }}>
          <span style={{ color:T.fb, fontWeight:900, fontSize:"26px", fontFamily:"Georgia,serif" }}>facebook</span>
          <div style={{ display:"flex", gap:"8px" }}>
            {["＋","🔍","☰"].map(ic=>(
              <div key={ic} style={{ width:34,height:34,borderRadius:"50%",background:"#e4e6eb",
                display:"flex",alignItems:"center",justifyContent:"center",fontSize:"16px" }}>{ic}</div>
            ))}
          </div>
        </div>
        {/* Nav icons */}
        <div style={{ background:"#fff", display:"flex", borderBottom:"2px solid #f0f2f5" }}>
          {[["🏠",notifCount],["👥",null],["💬",null],["🎬",notifCount],["🔔",null],["🛒",null]].map(([ic,badge],i)=>(
            <div key={i} style={{ flex:1, padding:"8px 0", display:"flex", alignItems:"center",
              justifyContent:"center", position:"relative",
              borderBottom: i===0?`3px solid ${T.fb}`:"3px solid transparent" }}>
              <span style={{ fontSize:"20px" }}>{ic}</span>
              {badge&&<div style={{ position:"absolute", top:"4px", right:"18%",
                background:T.danger, color:"#fff", fontSize:"9px", fontWeight:700,
                padding:"1px 4px", borderRadius:"10px" }}>{badge}</div>}
            </div>
          ))}
        </div>
        {/* Post */}
        <div style={{ background:"#fff" }}>
          <div style={{ padding:"10px 14px", display:"flex", alignItems:"center", gap:"10px" }}>
            <div style={{ position:"relative" }}>
              <Avatar image={avatar} size={42} initials={name.charAt(0)} bgColor={avatarBg}/>
              <div style={{ position:"absolute", bottom:0, right:0, width:12, height:12,
                borderRadius:"50%", background:"#31a24c", border:"2px solid #fff" }}/>
            </div>
            <div style={{ flex:1 }}>
              <div style={{ display:"flex", alignItems:"center", gap:"4px" }}>
                <span style={{ color:"#050505", fontWeight:700, fontSize:"15px" }}>{name}</span>
                {verified&&<span style={{ color:T.fb, fontSize:"13px", fontWeight:700 }}>✓</span>}
              </div>
              <div style={{ color:"#65676b", fontSize:"12px", display:"flex", alignItems:"center", gap:"3px" }}>
                <span>{time}</span><span>·</span><span>🌍</span>
              </div>
            </div>
            <span style={{ color:"#65676b", fontSize:"22px", fontWeight:700 }}>···</span>
            <span style={{ color:"#65676b", fontSize:"16px" }}>✕</span>
          </div>
          <div style={{ padding:"0 14px 12px", color:"#050505", fontSize:"15px", lineHeight:1.55, whiteSpace:"pre-line" }}>{postText}</div>
          {postImage&&<div style={{ width:"100%", maxHeight:"260px", overflow:"hidden" }}>
            <img src={postImage} style={{ width:"100%", objectFit:"cover" }} alt="post"/>
          </div>}
          <div style={{ padding:"6px 14px", display:"flex", justifyContent:"space-between" }}>
            <div style={{ display:"flex", alignItems:"center", gap:"2px" }}>
              <span>👍</span><span>❤️</span><span>😂</span>
              <span style={{ color:"#65676b", fontSize:"13px", marginLeft:"4px" }}>{likes}</span>
            </div>
            <span style={{ color:"#65676b", fontSize:"13px" }}>{comments} comments · {shares} shares</span>
          </div>
          <div style={{ margin:"0 14px", height:"1px", background:"#e4e6eb" }}/>
          <div style={{ display:"flex", padding:"2px 4px 8px" }}>
            {[["👍","Like"],["💬","Comment"],["↗️","Share"]].map(([ic,lb])=>(
              <button key={lb} style={{ flex:1, padding:"8px 4px", background:"none", border:"none",
                color:"#65676b", fontWeight:600, fontSize:"13px", cursor:"pointer",
                display:"flex", alignItems:"center", justifyContent:"center", gap:"4px", borderRadius:"6px" }}>
                <span>{ic}</span><span>{lb}</span>
              </button>
            ))}
          </div>

          {/* ── COMMENTS SECTION ── */}
          {fakeComments.length > 0 && (
            <div style={{ borderTop:"1px solid #e4e6eb", padding:"10px 14px", background:"#f0f2f5" }}>
              {fakeComments.map(cmt=>(
                <div key={cmt.id} style={{ display:"flex", gap:"8px", marginBottom:"10px", position:"relative" }}>
                  {/* Avatar */}
                  <div style={{ width:32, height:32, borderRadius:"50%", flexShrink:0,
                    background:`hsl(${cmt.name.charCodeAt(0)*23%360},50%,45%)`,
                    display:"flex", alignItems:"center", justifyContent:"center",
                    color:"#fff", fontWeight:700, fontSize:"13px" }}>
                    {cmt.name.charAt(0)}
                  </div>
                  {/* Bubble */}
                  <div style={{ flex:1 }}>
                    <div style={{ background:"#fff", borderRadius:"16px", padding:"7px 12px",
                      boxShadow:"0 1px 2px rgba(0,0,0,0.08)", display:"inline-block", maxWidth:"100%" }}>
                      <div style={{ color:"#050505", fontWeight:700, fontSize:"12px" }}>{cmt.name}</div>
                      <div style={{ color:"#050505", fontSize:"13px", lineHeight:1.4 }}>{cmt.text}</div>
                    </div>
                    <div style={{ display:"flex", gap:"12px", marginTop:"3px", padding:"0 4px" }}>
                      <span style={{ color:"#65676b", fontSize:"11px" }}>{cmt.time}</span>
                      <span style={{ color:"#65676b", fontSize:"11px", fontWeight:600, cursor:"pointer" }}>Like</span>
                      <span style={{ color:"#65676b", fontSize:"11px", fontWeight:600, cursor:"pointer" }}>Reply</span>
                    </div>
                  </div>
                  {/* Remove button (outside capture - overlays) */}
                  <button onClick={()=>removeComment(cmt.id)} style={{
                    position:"absolute", top:"-6px", right:"-6px",
                    background:T.danger, color:"#fff", border:"none", borderRadius:"50%",
                    width:"16px", height:"16px", fontSize:"9px", cursor:"pointer", lineHeight:1, zIndex:5 }}>×</button>
                </div>
              ))}
            </div>
          )}
        </div>
        <WM removed={wmRemoved} onRemoveClick={()=>setShowWmModal(true)}/>
      </div>

      {/* Comment editor — outside preview */}
      <div style={{ background:T.bg, border:`1px solid ${T.border}`, borderRadius:"10px", padding:"12px", marginTop:"14px" }}>
        <div style={{ color:T.muted, fontSize:"11px", fontWeight:600, textTransform:"uppercase", letterSpacing:"0.06em", marginBottom:"8px" }}>💬 Add Fake Comment</div>
        <div style={{ display:"flex", gap:"8px", marginBottom:"8px" }}>
          <input value={newCmtName} onChange={e=>setNewCmtName(e.target.value)}
            style={{ ...inp, flex:1 }} placeholder="Commenter name"/>
        </div>
        <div style={{ display:"flex", gap:"8px" }}>
          <input value={newCmt} onChange={e=>setNewCmt(e.target.value)}
            style={{ ...inp, flex:1 }} placeholder="Comment text..."
            onKeyDown={e=>e.key==="Enter"&&addComment()}/>
          <button onClick={addComment} style={{ padding:"9px 16px", background:T.fb, color:"#fff",
            border:"none", borderRadius:"8px", fontWeight:700, fontSize:"14px", cursor:"pointer" }}>Add</button>
        </div>
      </div>
      {showWmModal && <RemoveWMModal onClose={()=>setShowWmModal(false)} onRemoved={()=>setWmRemoved(true)} />}
      <SaveBar previewRef={ref} filename="facebook-prank" wmRemoved={wmRemoved} onWmRemoved={()=>setWmRemoved(true)} onOpenModal={()=>setShowWmModal(true)}/>
    </div>
  );
}

// ════════════════════════════════════════════════════════════════
// MAIN APP
// ════════════════════════════════════════════════════════════════
const TABS = [
  { id:"whatsapp", label:"WhatsApp", icon:"💬" },
  { id:"payment",  label:"Receipt",  icon:"🧾" },
  { id:"facebook", label:"Facebook", icon:"👥" },
];

export default function PrankForge() {
  return (
    <ProProvider>
      <AppInner/>
    </ProProvider>
  );
}

function AppInner() {
  const { isPro } = usePro();
  const [accepted, setAccepted]   = useState(false);
  const [activeTab, setActiveTab] = useState("whatsapp");

  if (!accepted) return <Disclaimer onAccept={()=>setAccepted(true)}/>;

  return (
    <>
      <style>{`* { box-sizing:border-box; } body { margin:0; } @keyframes spin { to { transform:rotate(360deg); } }`}</style>
      <div style={{ minHeight:"100vh", background:T.bg, color:T.text,
        fontFamily:"'Segoe UI',system-ui,sans-serif", paddingBottom:"40px" }}>

        {/* Header */}
        <div style={{ background:`linear-gradient(135deg,${T.accent} 0%,#4f46e5 100%)`,
          padding:"18px 20px 22px", boxShadow:"0 4px 24px rgba(124,58,237,0.4)" }}>
          <div style={{ display:"flex", alignItems:"center", gap:"10px" }}>
            <span style={{ fontSize:"26px" }}>🎭</span>
            <div>
              <div style={{ fontWeight:800, fontSize:"22px", letterSpacing:"-0.02em" }}>PrankForge</div>
              <div style={{ fontSize:"12px", opacity:0.8 }}>Prank your friends — responsibly 😄</div>
            </div>
            <div style={{ marginLeft:"auto" }}>
              {isPro ? (
                <div style={{ background:"linear-gradient(135deg,#f59e0b,#d97706)",
                  padding:"4px 12px", borderRadius:"20px", fontSize:"12px", fontWeight:800 }}>
                  ⭐ PRO
                </div>
              ) : (
                <div style={{ background:"rgba(255,255,255,0.15)",
                  padding:"4px 10px", borderRadius:"20px", fontSize:"11px", fontWeight:700 }}>
                  FOR FUN ONLY
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div style={{ display:"flex", background:T.surface, borderBottom:`1px solid ${T.border}`,
          position:"sticky", top:0, zIndex:10 }}>
          {TABS.map(tab=>(
            <button key={tab.id} onClick={()=>setActiveTab(tab.id)} style={{
              flex:1, padding:"12px 8px", background:"none", border:"none",
              borderBottom: activeTab===tab.id?`3px solid ${T.accent}`:"3px solid transparent",
              color: activeTab===tab.id?T.accentLight:T.muted,
              fontWeight: activeTab===tab.id?700:500,
              fontSize:"13px", cursor:"pointer",
              display:"flex", flexDirection:"column", alignItems:"center", gap:"2px",
            }}>
              <span style={{ fontSize:"18px" }}>{tab.icon}</span>{tab.label}
            </button>
          ))}
        </div>

        {/* Content */}
        <div style={{ padding:"18px 16px", maxWidth:"480px", margin:"0 auto" }}>
          {activeTab==="whatsapp" && <WhatsAppGen/>}
          {activeTab==="payment"  && <PaymentGen/>}
          {activeTab==="facebook" && <FacebookGen/>}

          {/* Coming soon */}
          <div style={{ marginTop:"28px", background:T.surface, border:`1px dashed ${T.border}`,
            borderRadius:"14px", padding:"20px", textAlign:"center" }}>
            <div style={{ fontSize:"22px", marginBottom:"8px" }}>🔜</div>
            <div style={{ color:T.text, fontWeight:700, marginBottom:"6px" }}>Coming Soon</div>
            <div style={{ color:T.muted, fontSize:"13px" }}>
              Fake SMS • Instagram DM • Fake Email • Flight Ticket • NYSC Letter • University Admission
            </div>
            <div style={{ marginTop:"12px", display:"inline-block", background:T.accentGlow,
              border:`1px solid rgba(124,58,237,0.3)`, color:T.accentLight,
              padding:"6px 14px", borderRadius:"20px", fontSize:"12px", fontWeight:600 }}>
              ⭐ PRO unlocks all premium templates
            </div>
          </div>

          {/* Ad slot */}
          <div style={{ marginTop:"18px", background:T.surface, border:`1px solid ${T.border}`,
            borderRadius:"10px", padding:"12px", textAlign:"center" }}>
            <div style={{ color:T.muted, fontSize:"10px", marginBottom:"6px" }}>ADVERTISEMENT</div>
            <div style={{ background:"linear-gradient(90deg,#1a1a2e,#16213e)", borderRadius:"8px",
              padding:"14px", color:T.muted, fontSize:"13px" }}>📱 AdMob Banner Slot — 320×50</div>
          </div>
        </div>
      </div>
    </>
  );
}  // end AppInner
